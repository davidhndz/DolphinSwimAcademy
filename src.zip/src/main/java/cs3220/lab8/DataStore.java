package cs3220.lab8;

import cs3220.lab8.model.Student;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.NoSuchElementException;

@Component
public class DataStore {
    private final ArrayList<Student> entries;

    private int nextId;

    public DataStore() {
        entries = new ArrayList<>();
        nextId = 1;
        addEntry("Alice", "2004", 1, "9am", "10am", 2);
        addEntry("Bob", "1999", 2, "10am", "11am", 1);
        addEntry("Charlie", "2000", 3, "11am", "12pm", 4);
        addEntry("David", "2005", 4, "12pm", "1pm", 3);
    }

    public void addEntry(String name, String birthYear, int level, String time1, String time2, int session) {
        entries.add(new Student(name, birthYear, level, time1, time2, nextId++, session));
    }

    public ArrayList<Student> getEntries() {
        return entries;
    }

    public Student getEntry(int id) {
        for (Student entry : entries) {
            if (entry.getId() == id) {
                return entry;
            }
        }

        throw new NoSuchElementException("No student entry found for id " + id);
    }

    public ArrayList<Student> getEntriesBySession(int session) {
        ArrayList<Student> students = new ArrayList<>();
        for (Student student: entries) {
            if (student.getSession() == session) {
                students.add(student);
            }
        }
        return students;
    }
}
