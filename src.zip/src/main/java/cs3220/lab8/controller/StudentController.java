package cs3220.lab8.controller;

import cs3220.lab8.DataStore;
import cs3220.lab8.model.Student;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class StudentController {
    private final DataStore dataStore;

    public StudentController (DataStore dataStore){
        this.dataStore = dataStore;
    }

    @RequestMapping("/")
    public String index(Model model) {
        return "index";
    }

    @GetMapping("/register")
    public String register(Model model) {
        return "register";
    }

    @RequestMapping("/success")
    public String success() {
        return "success";
    }

    @PostMapping("/register")
    public String register( @RequestParam String name, @RequestParam String birthYear, @RequestParam int level, @RequestParam int session, @RequestParam String time1, @RequestParam String time2) {
        dataStore.addEntry(name, birthYear, level, time1, time2, session);
        return "redirect:/success";
    }

    @GetMapping("/students")
    public String register(Model model, @RequestParam(defaultValue = "1") int session) {

        model.addAttribute("students", dataStore.getEntriesBySession(session));
        return "students";
    }

}
